﻿using System.ComponentModel.DataAnnotations;

namespace AspNetCoreAnimalsWebProject.Models
{
    public class Animals
    {
        [Key]
        public int AnimalId { get; set; }
        public string? Name { get; set; }
        public int Age { get; set; }
        public string? PictureName { get; set; }
        public string? Description { get; set; }
        public int CategoryId { get; set; }
    }
}
