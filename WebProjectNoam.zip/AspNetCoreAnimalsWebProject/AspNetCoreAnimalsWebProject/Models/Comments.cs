﻿using System.ComponentModel.DataAnnotations;

namespace AspNetCoreAnimalsWebProject.Models
{
    public class Comments
    {
        [Key]
        public int CommentId { get; set; }
        public int AnimalId { get; set; }
        public string? Comment { get; set; }

    }
}
