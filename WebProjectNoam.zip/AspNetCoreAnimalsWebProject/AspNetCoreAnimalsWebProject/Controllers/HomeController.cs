﻿using AspNetCoreAnimalsWebProject.Data;
using AspNetCoreAnimalsWebProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace AspNetCoreAnimalsWebProject.Controllers
{
    public class HomeController : Controller
    {
        private AnimalContext _context;

        public HomeController(AnimalContext context)
        {
            _context = context;
        }

        public IActionResult ShowHomePage()
        {

            var animalsWithCommentCounts = _context.Animals
            .Join(
            _context.Comments,
            animal => animal.AnimalId,
            comment => comment.AnimalId,
            (animal, comment) => new { Animal = animal, Comment = comment }
            )
            .GroupBy(
            x => x.Animal,
            x => x.Comment,
            (animal, comments) => new
            {
                Animal = animal,
                CommentCount = comments.Count()
            }
            )
          .OrderByDescending(x => x.CommentCount)
          .Take(2)
          .ToList();

            return View("HomePageView", animalsWithCommentCounts);
        }

        public IActionResult ShowCatalogPage()
        {
            ViewBag.CategoryList = _context.Categories;
            var animalList = _context.Animals;
            return View("CatalogPageView", animalList);
        }

        public IActionResult ShowAnimalPage(int animalId, string myText)
        {
            var animal = _context.Animals.FirstOrDefault(a => a.AnimalId == animalId);
            if (animal == null)
            {
                return NotFound();
            }


            var category = _context.Categories.FirstOrDefault(c => c.CategoryId == animal.CategoryId);
            if (category == null)
            {
                return NotFound();
            }

            int commentID = _context.Comments.Max(c => c.CommentId) + 1;


            //validating user input and adding the comment to the comments list
            if (!myText.IsNullOrEmpty())
            {
                _context.Comments.Add(new Comments { AnimalId = animal.AnimalId, Comment = myText });
                _context.SaveChanges();
            }


            var commentsList = _context.Comments
            .Where(c => c.AnimalId == animal.AnimalId)
            .Select(c => c.Comment)
            .ToList();


            ViewBag.CommentsList = commentsList;
            ViewBag.CategoryName = category.Name;


            return View("AnimalPageView", animal);
        }


        public IActionResult DeleteAnimal(int animalId)
        {
            var animal = _context.Animals.FirstOrDefault(a => a.AnimalId == animalId);
            var animalList = _context.Animals;

            if (animal == null)
            {
                return NotFound();
            }

            _context.Animals.Remove(animal);
            _context.SaveChanges();
            var updatedAnimalList = _context.Animals; // Get the updated animal list

            ViewBag.AnimalName = animal.Name;
            ViewBag.CategoryList = _context.Categories;

            TempData["DeleteSuccess"] = true;


            return View("AdminPageView", updatedAnimalList);

        }

        public IActionResult ShowNewAnimalPage()
        {
            ViewBag.CategoryList = _context.Categories;

            return View("NewAnimalPageView");
        }

        public ActionResult CreateAnimal(IFormCollection form, IFormFile pictureFile)
        {
            string animalName = form["animalName"].ToString();
            int animalAge = Convert.ToInt32(form["animalAge"]);
            string animalDescription = form["animalDescription"].ToString();
            int animalCategory = Convert.ToInt32(form["animalCategory"]);

            int categoryID = 0;
            var category = _context.Categories.FirstOrDefault(c => c.CategoryId == animalCategory);


            if (category != null)
            {
                categoryID = category.CategoryId;
            }

            Animals animal = new Animals
            {
                Age = animalAge,
                Name = animalName,
                Description = animalDescription,
                CategoryId = categoryID
            };

            if (pictureFile != null && pictureFile.Length > 0)
            {
                // Get the file name
                var fileName = Path.GetFileName(pictureFile.FileName);

                // Save the file to a desired location
                var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Images", fileName);
                using (var fileStream = new FileStream(imagePath, FileMode.Create))
                {
                    pictureFile.CopyTo(fileStream);
                }

                var pictureName = fileName;
                animal.PictureName = pictureName;
            }

            _context.Animals.Add(animal);
            _context.SaveChanges();

            return RedirectToAction("ShowAdminPage");
        }
        public IActionResult ShowAdminPage()
        {
            ViewBag.CategoryList = _context.Categories;
            var animalList = _context.Animals;

            return View("AdminPageView", animalList);
        }


        public IActionResult ShowEditAnimalPage(int animalId)
        {
            ViewBag.CategoryList = _context.Categories;

            var animal = _context.Animals.FirstOrDefault(a => a.AnimalId == animalId);
            if (animal == null)
            {
                return NotFound();
            }
            var category = _context.Categories.FirstOrDefault(c => c.CategoryId == animal.CategoryId);
            if (category == null)
            {
                return NotFound();
            }

            ViewBag.AnimalID = animalId;
            ViewBag.CategoryName = category.Name;

            return View("EditAnimalPageView", animal);
        }

        public IActionResult EditAnimal(IFormCollection form, int AnimalID, IFormFile pictureFile)
        {
            string animalName = form["animalName"].ToString();
            int animalAge = Convert.ToInt32(form["animalAge"]);
            string animalDescription = form["animalDescription"].ToString();
            int animalCategoryID = Convert.ToInt32(form["animalCategory"]);


            var animal = _context.Animals.FirstOrDefault(a => a.AnimalId == AnimalID);

            animal.Name = animalName;
            animal.Age = animalAge;
            animal.Description = animalDescription;
            animal.CategoryId = animalCategoryID;


            if (pictureFile != null && pictureFile.Length > 0)
            {
                // Get the file name
                var fileName = Path.GetFileName(pictureFile.FileName);

                // Save the file to a desired location
                var imagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Images", fileName);
                using (var fileStream = new FileStream(imagePath, FileMode.Create))
                {
                    pictureFile.CopyTo(fileStream);
                }

                // Update the PictureName property
                var pictureName = fileName;
                animal.PictureName = pictureName;
            }



            _context.SaveChanges();

            return RedirectToAction("ShowAdminPage");
        }

    }
}

