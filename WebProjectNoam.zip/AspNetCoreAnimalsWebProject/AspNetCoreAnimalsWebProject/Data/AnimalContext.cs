﻿using AspNetCoreAnimalsWebProject.Models;
using Microsoft.EntityFrameworkCore;

namespace AspNetCoreAnimalsWebProject.Data
{
    public class AnimalContext : DbContext
    {

        public AnimalContext(DbContextOptions<AnimalContext> options)
        : base(options)
        {
        }

        public DbSet<Categories> Categories { get; set; }
        public DbSet<Animals> Animals { get; set; }
        public DbSet<Comments> Comments { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            var categories = new List<Categories>
            {
                new Categories { CategoryId = 1, Name = "Mammals" },
                new Categories { CategoryId = 2, Name = "Birds" },
                new Categories { CategoryId = 3, Name = "Reptiles" },
                new Categories { CategoryId = 4, Name = "Fish" },
                new Categories { CategoryId = 5, Name = "Amphibians" },
                new Categories { CategoryId = 6, Name = "Insects" },
                new Categories { CategoryId = 7, Name = "Arachnids" },
                new Categories { CategoryId = 8, Name = "Marine Animals" }
            };
            modelBuilder.Entity<Categories>().HasData(categories);



            var animals = new List<Animals>
            {
                new Animals { AnimalId = 1, Name = "Lion", Age = 5, PictureName = "lion.png", Description = "The king of the jungle", CategoryId = 1 },
                new Animals { AnimalId = 2, Name = "Eagle", Age = 3, PictureName = "eagle.png", Description = "A majestic bird of prey", CategoryId = 2 },
                new Animals { AnimalId = 3, Name = "Snake", Age = 2, PictureName = "snake.png", Description = "A slithering reptile", CategoryId = 3 },
                new Animals { AnimalId = 4, Name = "Goldfish", Age = 1, PictureName = "goldfish.png", Description = "A small and colorful fish", CategoryId = 4 },
                new Animals { AnimalId = 5, Name = "Frog", Age = 1, PictureName = "frog.png", Description = "An amphibian with a unique lifecycle", CategoryId = 5 },
                new Animals { AnimalId = 6, Name = "Butterfly", Age = 0, PictureName = "butterfly.png", Description = "A beautiful insect that undergoes metamorphosis", CategoryId = 6 },
                new Animals { AnimalId = 7, Name = "Spider", Age = 1, PictureName = "spider.png", Description = "An eight-legged arachnid", CategoryId = 7 },
                new Animals { AnimalId = 8, Name = "Dolphin", Age = 10, PictureName = "dolphin.png", Description = "A highly intelligent marine mammal", CategoryId = 8 },
                new Animals { AnimalId = 9, Name = "Giraffe", Age = 7, PictureName = "giraffe.png", Description = "A tall and graceful mammal with a long neck", CategoryId = 1 },
                new Animals { AnimalId = 10, Name = "Hawk", Age = 4, PictureName = "hawk.png", Description = "A bird of prey known for its keen eyesight", CategoryId = 2 },
                new Animals { AnimalId = 11, Name = "Turtle", Age = 15, PictureName = "turtle.png", Description = "A reptile with a protective shell", CategoryId = 3 },
                new Animals { AnimalId = 12, Name = "Shark", Age = 20, PictureName = "shark.png", Description = "A large and powerful marine fish", CategoryId = 4 },
                new Animals { AnimalId = 13, Name = "Salamander", Age = 3, PictureName = "salamander.png", Description = "An amphibian with the ability to regenerate limbs", CategoryId = 5 },
                new Animals { AnimalId = 14, Name = "Dragonfly", Age = 0, PictureName = "dragonfly.png", Description = "An insect known for its agile flight", CategoryId = 6 },
                new Animals { AnimalId = 15, Name = "Scorpion", Age = 2, PictureName = "scorpion.png", Description = "An arachnid with a venomous stinger", CategoryId = 7 },
                new Animals { AnimalId = 16, Name = "Whale", Age = 30, PictureName = "whale.png", Description = "A massive marine mammal", CategoryId = 8 }
            };
            modelBuilder.Entity<Animals>().HasData(animals);



            var comments = new List<Comments>
            {
               // Comments for Animal ID 1 (Lion)
            new Comments { CommentId = 1, AnimalId = 1, Comment = "The lion is magnificent!" },
            new Comments { CommentId = 2, AnimalId = 1, Comment = "I love lions!" },
            new Comments { CommentId = 10, AnimalId = 1, Comment = "The lion's roar is powerful!" },
            new Comments { CommentId = 11, AnimalId = 1, Comment = "Lions are apex predators." },
            new Comments { CommentId = 21, AnimalId = 1, Comment = "Lions are known for their majestic manes." },
            new Comments { CommentId = 35, AnimalId = 1, Comment = "Male lions are recognizable by their impressive manes." },

            // Comments for Animal ID 2 (Eagle)
            new Comments { CommentId = 3, AnimalId = 2, Comment = "Eagles are amazing birds!" },
            new Comments { CommentId = 12, AnimalId = 2, Comment = "Eagles have incredible eyesight." },
            new Comments { CommentId = 13, AnimalId = 2, Comment = "I enjoy watching eagles soar through the sky." },
            new Comments { CommentId = 22, AnimalId = 2, Comment = "Eagles have excellent hunting skills." },
            new Comments { CommentId = 23, AnimalId = 2, Comment = "Watching eagles in flight is a breathtaking sight." },

            // Comments for Animal ID 3 (Snake)
            new Comments { CommentId = 4, AnimalId = 3, Comment = "Snakes are fascinating creatures." },
            new Comments { CommentId = 14, AnimalId = 3, Comment = "Some snakes are venomous, while others are not." },
            new Comments { CommentId = 24, AnimalId = 3, Comment = "Some snakes can swallow prey larger than their own heads." },
            new Comments { CommentId = 25, AnimalId = 3, Comment = "Snakes play an important role in balancing ecosystems." },

            // Comments for Animal ID 4 (Goldfish)
            new Comments { CommentId = 5, AnimalId = 4, Comment = "Goldfish are beautiful." },
            new Comments { CommentId = 15, AnimalId = 4, Comment = "Goldfish are often kept as pets." },
            new Comments { CommentId = 26, AnimalId = 4, Comment = "Goldfish come in a variety of colors and patterns." },

            // Comments for Animal ID 5 (Frog)
            new Comments { CommentId = 6, AnimalId = 5, Comment = "Frogs have such unique life cycles." },
            new Comments { CommentId = 16, AnimalId = 5, Comment = "Frogs are known for their unique croaking sounds." },
            new Comments { CommentId = 17, AnimalId = 5, Comment = "Frogs undergo metamorphosis from tadpoles to adults." },
            new Comments { CommentId = 27, AnimalId = 5, Comment = "Frogs help control insect populations in their habitats." },

            // Comments for Animal ID 6 (Butterfly)
            new Comments { CommentId = 7, AnimalId = 6, Comment = "Butterflies are so colorful!" },
            new Comments { CommentId = 18, AnimalId = 6, Comment = "Butterflies play an important role in pollination." },
            new Comments { CommentId = 28, AnimalId = 6, Comment = "Butterflies go through four stages of metamorphosis." },
            new Comments { CommentId = 29, AnimalId = 6, Comment = "Butterflies have delicate and intricate wing patterns." },

            // Comments for Animal ID 7 (Spider)
            new Comments { CommentId = 8, AnimalId = 7, Comment = "Spiders are creepy but interesting." },
            new Comments { CommentId = 19, AnimalId = 7, Comment = "Spiders weave intricate webs to catch their prey." },
            new Comments { CommentId = 30, AnimalId = 7, Comment = "Spiders are skilled weavers of silk." },
            new Comments { CommentId = 31, AnimalId = 7, Comment = "Some spiders are venomous and use webs to catch their prey." },

            // Comments for Animal ID 8 (Dolphin)
            new Comments { CommentId = 9, AnimalId = 8, Comment = "Dolphins are my favorite marine animals!" },
            new Comments { CommentId = 20, AnimalId = 8, Comment = "Dolphins are highly intelligent and social animals." },
            new Comments { CommentId = 32, AnimalId = 8, Comment = "Dolphins are highly sociable and often seen in groups." },
            new Comments { CommentId = 33, AnimalId = 8, Comment = "Dolphins are known for their acrobatic displays in the water." },

            // Comments for Animal ID 9 (Giraffe)
            new Comments { CommentId = 36, AnimalId = 9, Comment = "Giraffes have long necks to reach leaves on tall trees." },
            new Comments { CommentId = 37, AnimalId = 9, Comment = "Male giraffes fight by swinging their necks and heads." },

            // Comments for Animal ID 10 (Hawk)
            new Comments { CommentId = 38, AnimalId = 10, Comment = "Hawks have keen eyesight for hunting prey." },
            new Comments { CommentId = 39, AnimalId = 10, Comment = "Hawks are skilled flyers and hunters." },

            // Comments for Animal ID 11 (Turtle)
            new Comments { CommentId = 40, AnimalId = 11, Comment = "Turtles have a protective shell on their back." },
            new Comments { CommentId = 41, AnimalId = 11, Comment = "Some turtles can live for over a hundred years." },

            // Comments for Animal ID 12 (Shark)
            new Comments { CommentId = 42, AnimalId = 12, Comment = "Sharks are powerful and efficient predators." },
            new Comments { CommentId = 43, AnimalId = 12, Comment = "There are over 400 species of sharks." },

            // Comments for Animal ID 13 (Salamander)
            new Comments { CommentId = 44, AnimalId = 13, Comment = "Salamanders have the ability to regenerate limbs." },
            new Comments { CommentId = 45, AnimalId = 13, Comment = "Salamanders are amphibians with unique characteristics." },

            // Comments for Animal ID 14 (Dragonfly)
            new Comments { CommentId = 46, AnimalId = 14, Comment = "Dragonflies are agile fliers." },
            new Comments { CommentId = 47, AnimalId = 14, Comment = "Dragonflies have a long and slender body." },

            // Comments for Animal ID 15 (Scorpion)
            new Comments { CommentId = 48, AnimalId = 15, Comment = "Scorpions have a venomous stinger on their tail." },
            new Comments { CommentId = 49, AnimalId = 15, Comment = "Scorpions are nocturnal predators." },

            // Comments for Animal ID 16 (Whale)
            new Comments { CommentId = 50, AnimalId = 16, Comment = "Whales are the largest animals on Earth." },
            new Comments { CommentId = 51, AnimalId = 16, Comment = "Whales are known for their songs and underwater communication." }
            };
            modelBuilder.Entity<Comments>().HasData(comments);
        }
    }
}
